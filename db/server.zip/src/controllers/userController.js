import { getAllUsersData } from "../services/userService.js";

export const getAllUsersList = async (req, res) => {
    try {
        const users = await getAllUsersData();

        return res.status(200).json({
            message: "Users fetched successfully",
            success: true,
            users: users
        });
    } catch (error) {
        console.error("Fetch error:", error);
        return res.status(500).json({ message: "Failed to fetch videos" });
    }
};