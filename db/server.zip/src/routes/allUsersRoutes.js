import express from "express";
import { auth } from "../middleware/authMiddleware.js";
import { getAllUsersList } from "../controllers/userController.js";
const router = express.Router();

router.get("/getallusers", auth, getAllUsersList);

export default router;